CREATE TABLE `student` (
  `Rollno` int(11) NOT NULL,
  `Name` varchar(10) DEFAULT NULL,
  `Branch` varchar(20) NOT NULL
);



INSERT INTO `student` (`Rollno`, `Name`, `Branch`) VALUES
(1, 'Jay', 'Computer Science'),
(2, 'Suhani', 'Electronic and Com'),
(3, 'Kriti', 'Electronic and Com');


ALTER TABLE `student`
  ADD PRIMARY KEY (`Rollno`);
COMMIT;