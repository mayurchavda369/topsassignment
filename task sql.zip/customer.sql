CREATE TABLE `customer` (
  `PKCNM` int(11) DEFAULT NULL,
  `CNAME` varchar(10) DEFAULT NULL,
  `CITY` varchar(15) DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL,
  `FKSNo` int(11) DEFAULT NULL
);

INSERT INTO `customer` (`PKCNM`, `CNAME`, `CITY`, `Rating`, `FKSNo`) VALUES
(201, 'Hoffman', 'London', 100, 1001),
(202, 'Giovanne', 'Roe', 200, 1003),
(203, 'Liu', 'San Jose', 300, 1002),
(204, 'Grass', 'Barcelona', 100, 1002),
(206, 'Clemens', 'London', 300, 1007),
(207, 'Pereira', 'Roe', 100, 1004);
COMMIT;