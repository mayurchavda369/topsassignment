CREATE TABLE `salseperson` (
  `PKSNo` int(11) DEFAULT NULL,
  `SNAME` varchar(10) DEFAULT NULL,
  `CITY` varchar(15) DEFAULT NULL,
  `COMM` float DEFAULT NULL
);


INSERT INTO `salseperson` (`PKSNo`, `SNAME`, `CITY`, `COMM`) VALUES
(1001, 'Peel', 'London', 0.12),
(1002, 'Serres', 'San Jose', 0.13),
(1004, 'Motika', 'London', 0.11),
(1007, 'Rafkin', 'Barcelona', 0.15),
(1003, 'Axelrod', 'New York', 0.1);
COMMIT;