CREATE TABLE `exam` (
  `Rollno` int(11) NOT NULL,
  `S_code` varchar(10) DEFAULT NULL,
  `Marks` int(11) DEFAULT NULL,
  `P_code` varchar(5) DEFAULT NULL
);

INSERT INTO `exam` (`Rollno`, `S_code`, `Marks`, `P_code`) VALUES
(1, 'CS11', 50, 'CS'),
(1, 'CS12', 60, 'CS'),
(2, 'EC101', 66, 'EC'),
(2, 'EC102', 70, 'EC'),
(3, 'EC101', 45, 'EC'),
(3, 'EC102', 50, 'EC');

ALTER TABLE `exam`
  ADD KEY `Rollno` (`Rollno`);
ALTER TABLE `exam`
  ADD CONSTRAINT `exam_ibfk_1` FOREIGN KEY (`Rollno`) REFERENCES `student` (`Rollno`);
COMMIT;